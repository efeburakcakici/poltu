import 'package:flutter/material.dart';

Container divider() {
  return Container(
    decoration: const BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.only(
          topLeft: Radius.circular(10), topRight: Radius.circular(10)),
    ),
    child: Center(
      child: Container(
        width: 50,
        height: 4,
        margin: const EdgeInsets.symmetric(vertical: 10.0),
        decoration: const BoxDecoration(
          color: Color(0xffDADADA),
          borderRadius: BorderRadius.all(
            Radius.circular(50),
          ),
        ),
      ),
    ),
  );
}
