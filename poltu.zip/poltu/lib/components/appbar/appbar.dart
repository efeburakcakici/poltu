import 'package:flutter/material.dart';

class AppMenuAppBarLeading {
  AppMenuAppBarLeading({
    required this.onTap,
    this.icon = const SizedBox(),
  });
  final GestureTapCallback onTap;
  final Widget icon;
}

class AppMenuAppBar extends AppBar {
  final AppMenuAppBarLeading pLeading;
  final Widget pTitle;
  final List<Widget>? pActions;

  AppMenuAppBar({
    super.key,
    required this.pLeading,
    this.pActions,
    required this.pTitle,
  }) : super(
          backgroundColor: Colors.white,
          shadowColor: Colors.black,
          actionsIconTheme: const IconThemeData(
            color: Colors.black,
          ),
          elevation: 1,
          leadingWidth: 85,
          leading: Container(
            margin: const EdgeInsets.all(5),
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(25)),
            child: InkWell(
              onTap: pLeading.onTap,
              borderRadius: BorderRadius.circular(25),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(width: 4),
                  const Icon(
                    Icons.arrow_back,
                    color: Colors.black,
                  ),
                  pLeading.icon,
                ],
              ),
            ),
          ),
          centerTitle: false,
          titleSpacing: 0,
          title: pTitle,
          actions: pActions,
        );
}
