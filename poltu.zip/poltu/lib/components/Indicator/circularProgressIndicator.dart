// ignore_for_file: use_super_parameters

import 'package:flutter/material.dart';

class CustomCircularProgressIndicator extends StatelessWidget {
  const CustomCircularProgressIndicator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: const Center(
        child: RepaintBoundary(
          child: CircularProgressIndicator.adaptive(),
        ),
      ),
    );
  }
}
