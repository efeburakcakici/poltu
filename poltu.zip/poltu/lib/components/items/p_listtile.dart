import 'package:flutter/material.dart';

class PListTileItem extends StatelessWidget {
  final Widget? leading;
  final String title;
  final TextStyle? titleStyle;
  final String? subtitle;
  final TextStyle? subtitleStyle;
  final int subtitleMaxLine;
  final Widget? trailing;
  final bool defaultTrailing;
  final EdgeInsetsGeometry? contentPadding;
  final GestureTapCallback? onTap;
  final Color? splashColor;
  final Color? highlightColor;
  final double? horizontalTitleGap;
  final BorderRadius? borderRadius;
  final Color? backgroundColor;
  final bool enabled;

  const PListTileItem({
    super.key,
    required this.title,
    required this.onTap,
    this.leading,
    this.subtitle,
    this.trailing,
    this.defaultTrailing = true,
    this.titleStyle,
    this.subtitleStyle,
    this.subtitleMaxLine = 5,
    this.contentPadding,
    this.splashColor,
    this.highlightColor,
    this.horizontalTitleGap,
    this.borderRadius,
    this.backgroundColor,
    this.enabled = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      child: InkWell(
        onTap: enabled ? null : onTap,
        splashColor: splashColor,
        highlightColor: highlightColor,
        borderRadius: borderRadius,
        child: ListTile(
          contentPadding: contentPadding,
          horizontalTitleGap: horizontalTitleGap ?? 5,
          enabled: enabled,
          leading: leading,
          title: Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: subtitle != null
              ? Text(
                  subtitle!,
                  maxLines: subtitleMaxLine,
                  overflow: TextOverflow.ellipsis,
                )
              : null,
          trailing: defaultTrailing
              ? trailing ??
                  const Icon(
                    Icons.location_on,
                    color: Colors.blue,
                    size: 20,
                  )
              : null,
        ),
      ),
    );
  }
}
