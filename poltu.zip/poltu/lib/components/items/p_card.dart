import 'package:flutter/material.dart';

class PCard extends StatelessWidget {
  const PCard({
    super.key,
    this.margin,
    this.padding,
    this.borderRadius,
    this.color,
    this.elevated,
    required this.child,
  });
  final EdgeInsetsGeometry? margin;
  final EdgeInsetsGeometry? padding;
  final BorderRadiusGeometry? borderRadius;
  final Color? color;

  final double? elevated;
  final Widget? child;
  @override
  Widget build(BuildContext context) {
    final defauldBorderRadius = borderRadius ?? BorderRadius.circular(10);

    final defaultMargin = margin ?? const EdgeInsets.all(10);

    final defaultPadding = padding ?? const EdgeInsets.only();

    return Card(
      margin: defaultMargin,
      color: color,
      elevation: elevated,
      shape: RoundedRectangleBorder(
        borderRadius: defauldBorderRadius,
      ),
      child: ClipRRect(
        borderRadius: defauldBorderRadius,
        child: Padding(
          padding: defaultPadding,
          child: child,
        ),
      ),
    );
  }
}
