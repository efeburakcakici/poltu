import 'package:flutter/material.dart';
import 'package:poltu/models/delivery/model_delivery.dart';

class DashboardServiceProvider extends ChangeNotifier {
  final List<DeliveryData> _displayedData = [];

  List<DeliveryData> get displayedData => _displayedData;
  List<bool> isCheckedList = [];
}
