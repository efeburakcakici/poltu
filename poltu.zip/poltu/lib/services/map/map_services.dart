// ignore_for_file: prefer_final_fields, avoid_print, deprecated_member_use

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geocoding/geocoding.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class MarkerModel {
  final Marker markerID;
  final String customerName;
  final String customerNo;

  MarkerModel({
    required this.markerID,
    required this.customerName,
    required this.customerNo,
  });
}

class MapServiceProvider extends ChangeNotifier {
  Completer<GoogleMapController> _controller = Completer<GoogleMapController>();
  CameraPosition _initialCameraPosition = const CameraPosition(
    target: LatLng(41.0082, 28.9784),
    zoom: 14,
  );

  List<Marker> _markers = [];
  LatLng? _selectedPosition;
  String? _selectedTitle;
  Set<Polyline> _polylines = {};
  Position? _currentPosition;
  Marker? _currentLocationMarker;
  List<MarkerModel> _selectedMarkers = [];

  List<MarkerModel> get selectedMarkers => _selectedMarkers;

  MapServiceProvider() {
    _initialize();
  }

  CameraPosition get initialCameraPosition => _initialCameraPosition;
  List<Marker> get markers => _markers;
  LatLng? get selectedPosition => _selectedPosition;
  String? get selectedTitle => _selectedTitle;
  Set<Polyline> get polylines => _polylines;
  Completer<GoogleMapController> get controller => _controller;
  Position? get currentPosition => _currentPosition;
  Marker? get currentLocationMarker => _currentLocationMarker;

  Future<void> _initialize() async {
    await _requestLocationPermission();
    await _fetchCurrentLocation();
    await _initializeMarkers();
    await _updatePolylines();
    notifyListeners();
  }

  // Geçerli konumu alır ve ilgili marker'ı oluşturur
  Future<void> _fetchCurrentLocation() async {
    _currentPosition = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    _initialCameraPosition = CameraPosition(
      target: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
      zoom: 14,
    );
    _currentLocationMarker = Marker(
      markerId: const MarkerId("current"),
      position: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow),
      infoWindow: const InfoWindow(
        title: "My Current Location",
      ),
      onTap: () {
        _onMarkerTapped(
            LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
            "My Current Location");
      },
    );
    _updatePolylines();
    notifyListeners();
  }

  // Marker'ları başlatır dashboard dan iletilen data
  Future<void> _initializeMarkers() async {
    final List<MarkerModel> markerList = [];

    for (var markerModel in markerList) {
      final marker = markerModel.markerID.copyWith(
        onTapParam: () {
          _onMarkerTapped(
              markerModel.markerID.position, markerModel.customerName);
        },
      );
      _markers.add(marker);
    }
    _updatePolylines();
    notifyListeners();
  }

  void addMarker(MarkerModel markerModel) {
    final marker = markerModel.markerID.copyWith(
      onTapParam: () {
        _onMarkerTapped(
            markerModel.markerID.position, markerModel.customerName);
      },
    );
    _markers.add(marker);
    notifyListeners();
  }

  void clearMarkersAndPolylines() {
    _markers.clear();
    _polylines.clear();
    notifyListeners();
  }

  void clearSelectedMarkers() {
    _selectedMarkers.clear();
    notifyListeners();
  }

  Future<void> _updatePolylines() async {
    if (_currentPosition == null || _markers.isEmpty) {
      _polylines.clear();
      notifyListeners();
      return;
    }

    final LatLng currentLatLng =
        LatLng(_currentPosition!.latitude, _currentPosition!.longitude);
    final List<LatLng> polylineCoordinates = [
      currentLatLng,
    ];

    for (int i = 0; i < _markers.length; i++) {
      final LatLng origin = i == 0 ? currentLatLng : _markers[i - 1].position;
      final LatLng destination = _markers[i].position;

      if (origin != destination) {
        final String url =
            'https://maps.googleapis.com/maps/api/directions/json?origin=${origin.latitude},${origin.longitude}&destination=${destination.latitude},${destination.longitude}&key=AIzaSyBxyYlkSfMjBdbrqYc_5p4Uj-sb44vuooA';

        final response = await http.get(Uri.parse(url));
        if (response.statusCode == 200) {
          final decoded = jsonDecode(response.body);
          List<LatLng> points =
              _decodePoly(decoded['routes'][0]['overview_polyline']['points']);
          polylineCoordinates.addAll(points);
        } else {
          throw 'Failed to fetch route';
        }
      }
    }

    final Polyline polyline = Polyline(
      polylineId: const PolylineId('polyline'),
      color: Colors.blue,
      points: polylineCoordinates,
      width: 5,
    );

    _polylines.clear();
    _polylines.add(polyline);

    notifyListeners();
  }

// Polyline'ları decode eder.Yollar üzerinden çizim yapması için
  List<LatLng> _decodePoly(String encoded) {
    List<LatLng> points = [];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      double latitude = lat / 1E5;
      double longitude = lng / 1E5;
      points.add(LatLng(latitude, longitude));
    }
    return points;
  }

  void _onMarkerTapped(LatLng position, String title) {
    _selectedPosition = position;
    _selectedTitle = title;
    notifyListeners();
  }

  Future<void> goToCurrentLocation() async {
    if (_currentPosition != null) {
      final GoogleMapController controller = await _controller.future;
      await controller.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
          target:
              LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
          zoom: 16,
        ),
      ));
    } else {
      print('Current position is not available');
    }
    notifyListeners();
  }

  void closeInfoWindow() {
    clearSelectedPosition();
  }

//Haritada bilgi kartlarında ki CurrentLocation a yönlendirme
  Future<void> navigateToCurrentLocation() async {
    if (_currentPosition != null) {
      final GoogleMapController controller = await _controller.future;
      await controller.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
            target:
                LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
            zoom: 25,
          ),
        ),
      );
      closeInfoWindow();
      notifyListeners();
    } else {
      print('Current position is not available');
    }
  }

  Future<void> navigateToSelectedPosition() async {
    final GoogleMapController controller = await _controller.future;
    final LatLng destination = _selectedPosition!;
    final String startAddress =
        await getAddressFromLatLng(_initialCameraPosition.target);
    final String endAddress = await getAddressFromLatLng(destination);

    final String googleMapsUrl =
        'https://www.google.com/maps/dir/?api=1&origin=$startAddress&destination=$endAddress';
    if (await canLaunch(googleMapsUrl)) {
      await launch(googleMapsUrl);
    } else {
      throw 'Could not launch $googleMapsUrl';
    }

    await controller.animateCamera(CameraUpdate.newLatLngZoom(destination, 16));
  }

  void clearSelectedPosition() {
    _selectedPosition = null;
    notifyListeners();
  }

  void deleteMarkerAndPolyline(LatLng position) {
    _markers.removeWhere((marker) => marker.position == position);
    _updatePolylines();
    _selectedPosition = null;
    notifyListeners();
  }

  //Konum izni
  Future<void> _requestLocationPermission() async {
    if (await Permission.location.request().isGranted) {
      _startLocationTracking();
    } else {}
  }

  // Konum takibini başlatır ve konum değişikliklerini dinler
  void _startLocationTracking() {
    Geolocator.getPositionStream().listen((Position position) {
      _currentPosition = position;
      _updatePolylines();
      notifyListeners();
    });
  }

  // LatLng koordinatlarından adresi alır
  Future<String> getAddressFromLatLng(LatLng latLng) async {
    try {
      List<Placemark> placemarks =
          await placemarkFromCoordinates(latLng.latitude, latLng.longitude);
      Placemark place = placemarks[0];
      return "${place.name}, ${place.subLocality}, ${place.locality}, ${place.administrativeArea} ${place.postalCode}, ${place.country}";
    } catch (e) {
      return "Could not get address";
    }
  }

  Future<void> resetData() async {
    _markers.clear();
    _selectedPosition = null;
    _selectedTitle = null;
    _polylines.clear();
    _currentPosition = null;
    _currentLocationMarker = null;
    _selectedMarkers.clear();
    _controller = Completer();
    await _initialize();

    notifyListeners();
  }
}
