// ignore_for_file: deprecated_member_use

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../components/appbar/appbar.dart';
import '../../services/map/map_services.dart';

@RoutePage()
class MapSampleView extends StatefulWidget {
  const MapSampleView({super.key});

  @override
  State<MapSampleView> createState() => _MapSampleViewState();
}

class _MapSampleViewState extends State<MapSampleView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppMenuAppBar(
        pLeading: AppMenuAppBarLeading(
          onTap: () {
            context.read<MapServiceProvider>().resetData();
            Navigator.of(context).pop();
          },
        ),
        pTitle: const Text(
          'Maps',
          style: TextStyle(
            color: Colors.black,
            fontSize: 18.0,
          ),
        ),
        pActions: null,
      ),
      body: Stack(
        children: [
          _buildGoogleMap(),
          _buildCustomInfoWindow(),
        ],
      ),
      floatingActionButton: _buildCurrentLocationButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
    );
  }

  Widget _buildGoogleMap() {
    return Consumer<MapServiceProvider>(
      builder: (context, mapServiceProvider, child) {
        final allMarkers = [
          if (mapServiceProvider.currentLocationMarker != null)
            mapServiceProvider.currentLocationMarker!,
          ...mapServiceProvider.markers,
        ];
        return GoogleMap(
          markers: Set<Marker>.of(allMarkers),
          polylines: mapServiceProvider.polylines,
          initialCameraPosition: mapServiceProvider.initialCameraPosition,
          onMapCreated: (GoogleMapController controller) {
            mapServiceProvider.controller.complete(controller);
          },
          onTap: (LatLng position) {},
        );
      },
    );
  }

  Widget _buildCustomInfoWindow() {
    return Consumer<MapServiceProvider>(
      builder: (context, mapServiceProvider, child) {
        if (mapServiceProvider.selectedPosition != null) {
          return Positioned(
            top: 50,
            left: 20,
            right: 20,
            child: Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ListTile(
                    title: Text(mapServiceProvider.selectedTitle ?? ""),
                    subtitle: Text(
                      '${mapServiceProvider.selectedPosition?.latitude}, ${mapServiceProvider.selectedPosition?.longitude}',
                    ),
                    trailing: GestureDetector(
                      onTap: () {
                        mapServiceProvider.navigateToCurrentLocation();
                      },
                      child: const Icon(
                        Icons.navigation,
                        color: Colors.blue,
                        size: 28,
                      ),
                    ),
                  ),
                  ButtonBar(
                    children: [
                      if (mapServiceProvider.selectedTitle !=
                          "My Current Location")
                        TextButton(
                          onPressed: () {
                            final LatLng? selectedPosition =
                                mapServiceProvider.selectedPosition;
                            if (selectedPosition != null) {
                              final String googleMapsUrl =
                                  'https://www.google.com/maps/dir/?api=1&destination=${selectedPosition.latitude},${selectedPosition.longitude}&travelmode=driving&dir_action=navigate';
                              launch(googleMapsUrl);
                            }
                          },
                          child: const Row(
                            children: [
                              Icon(Icons.map, color: Colors.green),
                              SizedBox(width: 8),
                              Text(
                                'See on Google Maps',
                                style: TextStyle(color: Colors.blue),
                              ),
                            ],
                          ),
                        ),
                      TextButton(
                        onPressed: () {
                          mapServiceProvider.clearSelectedPosition();
                        },
                        child: const Text(
                          'Close',
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                      if (mapServiceProvider.selectedTitle !=
                          "My Current Location")
                        TextButton(
                          onPressed: () {
                            final LatLng? selectedPosition =
                                mapServiceProvider.selectedPosition;
                            if (selectedPosition != null) {
                              mapServiceProvider
                                  .deleteMarkerAndPolyline(selectedPosition);
                            }
                          },
                          child: const Text(
                            'Delete',
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          );
        } else {
          return Container();
        }
      },
    );
  }

  Widget _buildCurrentLocationButton() {
    return Consumer<MapServiceProvider>(
      builder: (context, mapServiceProvider, child) {
        return GestureDetector(
          onTap: () async {
            await mapServiceProvider.goToCurrentLocation();
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            height: 56.0,
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(28.0),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.my_location, color: Colors.white),
                SizedBox(width: 8),
                Text(
                  'Current Location',
                  style: TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
