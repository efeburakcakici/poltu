import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:poltu/components/items/p_card.dart';
import 'package:poltu/components/items/item_account.dart';
import 'package:poltu/components/text/text_custom.dart';
import 'package:poltu/services/map/map_services.dart';
import 'package:provider/provider.dart';

import '../../components/Indicator/circularProgressIndicator.dart';
import '../../router/app_router.dart';
import '../../models/delivery_static_data/model_markerModel.dart';

@RoutePage()
class DashboardView extends StatefulWidget {
  const DashboardView({super.key});

  @override
  State<DashboardView> createState() => _DashboardViewState();
}

class _DashboardViewState extends State<DashboardView> {
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _appBar(),
        drawer: _buildDrawerProfile(),
        body: Stack(
          children: [
            _buildContent(),
            _buildMapButton(),
          ],
        ),
      ),
    );
  }

  AppBar _appBar() {
    return AppBar(
      backgroundColor: Colors.blue,
      shadowColor: Colors.black,
      actionsIconTheme: const IconThemeData(
        color: Colors.black,
      ),
      elevation: 1,
      leadingWidth: 85,
      title: const Text(
        'Poltus Orders',
        style: TextStyle(
          color: Colors.white,
          fontSize: 18.0,
        ),
      ),
    );
  }

  Widget _buildContent() {
    return _isLoading
        ? const Center(
            child: CustomCircularProgressIndicator(),
          )
        : ListView.builder(
            itemCount: markerList.length,
            itemBuilder: (context, index) {
              final MarkerModelList markerModel = markerList[index];
              final Marker marker = markerModel.markerID;
              Color iconColor;
              if (index % 3 == 0) {
                iconColor = Colors.red;
              } else if (index % 3 == 1) {
                iconColor = Colors.green;
              } else {
                iconColor = Colors.blue;
              }
              return PCard(
                child: InkWell(
                  onTap: () {
                    MarkerModel newMarker = MarkerModel(
                      markerID: Marker(
                        markerId: marker.markerId,
                        position: marker.position,
                        infoWindow: InfoWindow(
                          title: marker.infoWindow.title ?? '',
                        ),
                      ),
                      customerName: markerModel.customerName,
                      customerNo: markerModel.customerPhoneNo,
                    );

                    context.read<MapServiceProvider>().addMarker(newMarker);

                    AutoRouter.of(context).push(const MapSampleRoute());
                  },
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12.0),
                        child: Icon(Icons.location_on, color: iconColor),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4.0),
                            Text(
                              marker.infoWindow.title ?? 'No Name',
                              style: const TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4.0),
                            customRow(
                              iconData: Icons.person,
                              text: markerModel.customerName,
                            ),
                            customRow(
                              iconData: Icons.phone,
                              text: markerModel.customerPhoneNo,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
  }

  Widget _buildMapButton() {
    return Positioned(
      bottom: 16,
      right: 16,
      child: ElevatedButton(
        onPressed: () {
          for (var markerModel in markerList) {
            MarkerModel newMarker = MarkerModel(
              markerID: Marker(
                markerId: markerModel.markerID.markerId,
                position: markerModel.markerID.position,
                infoWindow: InfoWindow(
                  title: markerModel.markerID.infoWindow.title ?? '',
                ),
              ),
              customerName: markerModel.customerName,
              customerNo: markerModel.customerPhoneNo,
            );

            context.read<MapServiceProvider>().addMarker(newMarker);
          }
          AutoRouter.of(context).push(const MapSampleRoute());
        },
        child: const Row(
          children: [
            Icon(Icons.my_location, color: Colors.blue),
            SizedBox(width: 4),
            Text(
              'See All Location',
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
      ),
    );
  }

  Widget customRow({
    required IconData iconData,
    required String text,
    Color iconColor = Colors.black,
    double iconSize = 14.0,
    double textSize = 14.0,
  }) {
    return Row(
      children: [
        Icon(
          iconData,
          size: iconSize,
          color: iconColor,
        ),
        const SizedBox(width: 4.0),
        Text(
          text,
          style: TextStyle(fontSize: textSize),
        ),
      ],
    );
  }

  Widget _buildDrawerProfile() {
    return Drawer(
      child: SafeArea(
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
          children: [
            const SizedBox(height: 10.0),
            const SizedBox(height: 5.0),
            const SizedBox(height: 15.0),
            const TextCustom(text: 'Account', color: Colors.grey),
            const SizedBox(height: 10.0),
            const ItemAccount(
              text: 'Profile setting',
              icon: Icons.person,
              colorIcon: 0xff01C58C,
            ),
            const ItemAccount(
              text: 'Change Password',
              icon: Icons.lock_rounded,
              colorIcon: 0xff1B83F5,
            ),
            const ItemAccount(
              text: 'Change Role',
              icon: Icons.swap_horiz_rounded,
              colorIcon: 0xffE62755,
            ),
            const ItemAccount(
              text: 'Dark mode',
              icon: Icons.dark_mode_rounded,
              colorIcon: 0xff051E2F,
            ),
            const SizedBox(height: 15.0),
            const TextCustom(text: 'Company', color: Colors.grey),
            const SizedBox(height: 10.0),
            const ItemAccount(
              text: 'Categories',
              icon: Icons.category_rounded,
              colorIcon: 0xff5E65CD,
            ),
            const ItemAccount(
              text: 'Products',
              icon: Icons.add,
              colorIcon: 0xff355773,
            ),
            const ItemAccount(
              text: 'Delivery',
              icon: Icons.delivery_dining_rounded,
              colorIcon: 0xff469CD7,
            ),
            const ItemAccount(
              text: 'Orders',
              icon: Icons.checklist_rounded,
              colorIcon: 0xffFFA136,
            ),
            const SizedBox(height: 15.0),
            const TextCustom(text: 'Personal', color: Colors.grey),
            const SizedBox(height: 10.0),
            const ItemAccount(
              text: 'Privacy & Policy',
              icon: Icons.policy_rounded,
              colorIcon: 0xff6dbd63,
            ),
            const ItemAccount(
              text: 'Security',
              icon: Icons.lock_outline_rounded,
              colorIcon: 0xff1F252C,
            ),
            const ItemAccount(
              text: 'Term & Conditions',
              icon: Icons.description_outlined,
              colorIcon: 0xff458bff,
            ),
            const ItemAccount(
              text: 'Help',
              icon: Icons.help_outline,
              colorIcon: 0xff4772e6,
            ),
            const Divider(),
            ItemAccount(
              text: 'Sign Out',
              icon: Icons.power_settings_new_sharp,
              colorIcon: 0xffF02849,
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }
}
