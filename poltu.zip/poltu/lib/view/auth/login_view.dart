import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:poltu/components/icons/font_awesome_flutter.dart';
import 'package:poltu/components/text/text_custom.dart';
import 'package:poltu/router/app_router.dart';
import 'package:poltu/components/buttons/btn_social.dart';

@RoutePage()
class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _appBar(),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _backGroundImage(size),
            _buttons(context),
          ],
        ),
      ),
    );
  }

  AppBar _appBar() {
    return AppBar(
      automaticallyImplyLeading: false,
      title: const Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          TextCustom(
              text: 'Poltus ',
              color: Color(0xff0C6CF2),
              fontWeight: FontWeight.w500,
              fontSize: 25),
          TextCustom(
              text: 'Delivery', fontSize: 25, fontWeight: FontWeight.w500),
        ],
      ),
      backgroundColor: Colors.white,
      elevation: 0,
    );
  }

  Column _buttons(BuildContext context) {
    return Column(
      children: [
        const BtnSocial(
          icon: FontAwesomeIcons.google,
          text: 'Sign up with Google',
          backgroundColor: Colors.white,
          isBorder: true,
          textColor: Colors.black,
        ),
        const SizedBox(height: 15.0),
        BtnSocial(
          icon: FontAwesomeIcons.envelope,
          text: 'Sign up with an Email ID',
          backgroundColor: Colors.black87,
          textColor: Colors.white,
          onPressed: () {},
        ),
        const SizedBox(height: 20.0),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(height: 1, width: 150, color: Colors.grey[300]),
            const TextCustom(
              text: 'Or',
              fontSize: 16,
            ),
            Container(height: 1, width: 150, color: Colors.grey[300])
          ],
        ),
        const SizedBox(height: 20.0),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: ElevatedButton(
            onPressed: () {
              context.router.push(const DashboardRoute());
            },
            child: const Text('Login'),
          ),
        ),
        const SizedBox(height: 20.0)
      ],
    );
  }

  Container _backGroundImage(Size size) {
    return Container(
      padding: const EdgeInsets.all(15.0),
      height: 350,
      width: size.width,
      child: SvgPicture.asset('assets/bike.svg'),
    );
  }
}
