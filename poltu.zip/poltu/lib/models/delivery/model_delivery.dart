import 'package:json_annotation/json_annotation.dart';

part 'model_delivery.g.dart';

@JsonSerializable()
class Delivery {
  Delivery({
    this.data,
    this.success,
    this.message,
    this.count,
  });

  List<DeliveryData>? data;
  bool? success;
  String? message;
  int? count;

  factory Delivery.fromJson(Map<String, dynamic> json) =>
      _$DeliveryFromJson(json);

  Map<String, dynamic> toJson() => _$DeliveryToJson(this);
}

@JsonSerializable()
class DeliveryData {
  DeliveryData({
    this.deliveryID,
    this.deliveryTypeID,
    this.deliveryName,
    this.logoImage,
    this.countryName,
    this.latitude,
    this.longitude,
  });

  String? deliveryID;
  String? deliveryTypeID;
  String? deliveryName;
  String? logoImage;
  String? countryName;
  double? latitude;
  double? longitude;

  factory DeliveryData.fromJson(Map<String, dynamic> json) =>
      _$DeliveryDataFromJson(json);

  Map<String, dynamic> toJson() => _$DeliveryDataToJson(this);
}
