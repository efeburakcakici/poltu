// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'model_delivery.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Delivery _$DeliveryFromJson(Map<String, dynamic> json) => Delivery(
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => DeliveryData.fromJson(e as Map<String, dynamic>))
          .toList(),
      success: json['success'] as bool?,
      message: json['message'] as String?,
      count: (json['count'] as num?)?.toInt(),
    );

Map<String, dynamic> _$DeliveryToJson(Delivery instance) => <String, dynamic>{
      'data': instance.data,
      'success': instance.success,
      'message': instance.message,
      'count': instance.count,
    };

DeliveryData _$DeliveryDataFromJson(Map<String, dynamic> json) => DeliveryData(
      deliveryID: json['deliveryID'] as String?,
      deliveryTypeID: json['deliveryTypeID'] as String?,
      deliveryName: json['deliveryName'] as String?,
      logoImage: json['logoImage'] as String?,
      countryName: json['countryName'] as String?,
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$DeliveryDataToJson(DeliveryData instance) =>
    <String, dynamic>{
      'deliveryID': instance.deliveryID,
      'deliveryTypeID': instance.deliveryTypeID,
      'deliveryName': instance.deliveryName,
      'logoImage': instance.logoImage,
      'countryName': instance.countryName,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
    };
