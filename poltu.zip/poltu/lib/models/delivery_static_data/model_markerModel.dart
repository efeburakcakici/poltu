import 'package:google_maps_flutter/google_maps_flutter.dart';

class MarkerModelList {
  final Marker markerID;
  final String customerName;
  final String customerPhoneNo;

  MarkerModelList(
      {required this.markerID,
      required this.customerName,
      required this.customerPhoneNo});
}

List<MarkerModelList> markerList = [
  MarkerModelList(
    markerID: const Marker(
      markerId: MarkerId("16"),
      position: LatLng(41.0025, 28.9715),
      infoWindow: InfoWindow(
        title: "Yeni Camii",
      ),
    ),
    customerName: "Derya Aslan",
    customerPhoneNo: "01234567890",
  ),
  MarkerModelList(
    markerID: const Marker(
      markerId: MarkerId("17"),
      position: LatLng(41.0065, 28.9776),
      infoWindow: InfoWindow(
        title: "Yerebatan Sarnıcı",
      ),
    ),
    customerName: "Elçin Bedir",
    customerPhoneNo: "01234567890",
  ),
  MarkerModelList(
    markerID: const Marker(
      markerId: MarkerId("18"),
      position: LatLng(41.0140, 28.9750),
      infoWindow: InfoWindow(
        title: "Çırağan Sarayı",
      ),
    ),
    customerName: "Volkan Kırcalı",
    customerPhoneNo: "0543234532",
  ),
];
